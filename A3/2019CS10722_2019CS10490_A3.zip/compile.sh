mpic++ -std=c++17 -O2 -pg -fopenmp -o parRead.o parRead.cpp
mpic++ -std=c++17 -O2 -pg -fopenmp -o userRead.o userRead.cpp
mpic++ -std=c++11 -O2 -pg -fopenmp -o main.o main.cpp 