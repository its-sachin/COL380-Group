cp $1/level.txt $2/level.txt
cp $1/indptr.txt $2/indptr.txt
cp $1/index.txt $2/index.txt
cp $1/max_level.txt $2/max_level.txt
cp $1/level_offset.txt $2/level_offset.txt
cp $1/ep.txt $2/ep.txt
cp $1/vect.txt $2/vect.txt