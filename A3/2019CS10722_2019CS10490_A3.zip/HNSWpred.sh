mpirun ./userRead.o $3 $1
mpirun ./main.o $1 $2 $3 $4